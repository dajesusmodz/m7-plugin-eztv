![EZTV Logo](/logo.png)

**Screenshot:**

![Screenshot](/Screenshots/1.png)

**Features:**



**How to Install:**

1) Placeholder

2) Placeholder

3) Placeholder

4) Placeholder

5) Placeholder

6) Placeholder



 ![Pre-Release Download (Branch Coming Soon)](/eztv_unstable.zip?raw=true)

**Available Languages:**

* English


